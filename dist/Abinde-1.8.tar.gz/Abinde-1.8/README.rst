Abinde
======

Abinde is a python module for pygame.

Advantages
============

- Easy to use
- Lightweight

Requirements
==============

- **pygame** for module.
- **PyOpenGL** for better pygame.
- **threading** for main loop.
- **python** for running module.
- **PIL** for image support

Please Note
=============

To use this module, you will need at least some experience with coding python.
